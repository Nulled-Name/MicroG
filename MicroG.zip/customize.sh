echo '(Echo1): '$MODPATH
echo "(Echo2): "$MODPATH
ui_print '(UI_Print1): '$MODPATH
ui_print "(UI_Print2): "$MODPATH