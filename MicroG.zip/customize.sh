ui_print "Magisk version: "$MAGISK_VER
ui_print "Magisk API: "$MAGISK_VER_CODE
ui_print "boot mode: "$BOOTMODE
ui_print "Module path: "$MODPATH
ui_print "temp path: "$TMPDIR
ui_print "zip path: "$ZIPFILE
ui_print "arch: "$ARCH
ui_print "Is 64 bit: "$IS64BIT
ui_print "android version: "$API
